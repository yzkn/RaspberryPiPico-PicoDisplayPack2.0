#include "pico/stdlib.h"

//DO NOT COMMIT THIS FILE!!!

//Your wireless network's name and password
#define NETWORK "network name here"
#define PASSWORD "network password here"
